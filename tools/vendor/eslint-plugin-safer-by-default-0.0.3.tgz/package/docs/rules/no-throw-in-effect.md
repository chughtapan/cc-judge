# `safer-by-default/no-throw-in-effect`

**What it flags:** A `throw` statement inside either an `Effect.gen(function* () { ... })` body or a function whose declared return type is `Effect.Effect<...>`. Throws inside a `catch` clause are not flagged (legitimate re-throw).

**Why:** Inside Effect, a `throw` lands in the *defect* channel (`Cause.Die`), not the typed *failure* channel. That has three consequences:

1. `.catchTag("Foo", ...)` and `.catchAll(...)` don't see defects — the consumer's fail-closed logic is bypassed.
2. The runtime surfaces a defect as an unrecoverable bug, often aborting the fiber.
3. Callers can't tell by the type signature that this Effect might die — the error channel lies.

The correct shape is `yield* Effect.fail(new TaggedError(...))`, which places the failure in the typed channel where `catchTag` sees it and the compiler knows about it.

## Before (flagged)

```ts
// Inside Effect.gen — throw lands in defect channel
const load = Effect.gen(function* () {
  const value = process.env.FOO;
  if (!value) throw new Error("FOO missing");
  return value;
});

// Inside Effect-returning function — same problem
function rotate(): Effect.Effect<void, ConfigError> {
  return Effect.gen(function* () {
    const current = yield* currentKey;
    if (!current) throw new Error("No active KEK found");
    // ...
  });
}
```

## After (preferred)

```ts
class MissingEnvError extends Data.TaggedError("MissingEnvError")<{
  readonly name: string;
}> {}

const load = Effect.gen(function* () {
  const value = process.env.FOO;
  if (!value) return yield* Effect.fail(new MissingEnvError({ name: "FOO" }));
  return value;
});

// Or better, use Effect.Config directly:
const load = Config.string("FOO");
```

## When to suppress

Very rarely. If you're writing a test helper that legitimately wants a defect (to assert the runtime surfaces it), suppress with a written reason:

```ts
// eslint-disable-next-line safer-by-default/no-throw-in-effect -- test harness: assert runtime surfaces the defect
const bomb = Effect.gen(function* () { throw new Error("boom"); });
expect(Effect.runPromiseExit(bomb)).resolves.toMatchObject({ _tag: "Die" });
```

## Related rules

- `safer-by-default/bare-catch` — its Effect-world after-picture is `Effect.try`/`Effect.tryPromise`, not try/throw chains.
- `safer-by-default/effect-catch-untyped` — sister rule on the `tryPromise` side.
