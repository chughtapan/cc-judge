# `safer-by-default/no-promise-or-void-handler`

**What it flags:** Callback and handler type declarations whose return type is the union `Promise<void> | void` (or the equivalent `void | Promise<void>`). Flags both function types (`type X = (arg) => Promise<void> | void`) and method signatures on interfaces.

**Why:** The union signature is a trap. Consider a library with:

```ts
interface Channel {
  onMessage: (msg: Message) => Promise<void> | void;
}
```

The consumer writes an async handler. The library author, looking at the signature, calls it without `await`:

```ts
for (const msg of batch) channel.onMessage(msg); // no await
```

Now:
- Async handler rejections are lost — no try/catch, no promise chain sees them.
- Ordering guarantees break — the next message is dispatched before the previous one settles.
- Errors visible in development (via `unhandledRejection` warnings) may be stripped in production by framework error handlers.

Pick one contract and hold both sides to it:

- **Effect handler** (`Effect.Effect<void, E>`) — errors are typed; the caller must `yield*` or explicitly `runFork`. Use this in Effect-first code.
- **Promise handler** (`Promise<void>`) — caller must `await`. Acceptable in non-Effect code as long as the caller enforces it.

Don't allow both.

## Before (flagged)

```ts
// Interface
interface Channel {
  onMessage: (msg: Message) => Promise<void> | void;
  onClose: (reason: string) => void | Promise<void>;
}

// Type alias
type EventHandler = (ctx: Ctx) => Promise<void> | void;
```

## After (preferred) — Effect-first

```ts
import { Effect } from "effect";

interface Channel {
  onMessage: (msg: Message) => Effect.Effect<void, ChannelError>;
  onClose: (reason: string) => Effect.Effect<void, never>;
}
```

## After (preferred) — Promise-first, consistent

```ts
interface Channel {
  onMessage: (msg: Message) => Promise<void>; // caller MUST await
  onClose: (reason: string) => Promise<void>;
}
```

## When to suppress

When integrating with an external library whose interface you can't change:

```ts
// eslint-disable-next-line safer-by-default/no-promise-or-void-handler -- mirrors upstream nanoclaw.Channel signature
export type ChannelAdapter = (msg: NanoclawMsg) => Promise<void> | void;
```

## Related rules

- `safer-by-default/async-keyword` — same family (Promise-first patterns leaking into Effect-first code).
- `safer-by-default/promise-type` — bans bare `Promise<T>` return annotations in Effect-first code.
