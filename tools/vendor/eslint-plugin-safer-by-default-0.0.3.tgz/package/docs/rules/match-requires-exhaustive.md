# `safer-by-default/match-requires-exhaustive`

**What it flags:** `Match.value(x).pipe(...)` chains where the last argument to `.pipe(...)` is not a terminal that closes the match. Recognized terminals:

- `Match.exhaustive` — compile-time exhaustiveness check; TS error if a variant is missed.
- `Match.orElse(fn)` — explicit fallback for unmatched cases.
- `Match.either(...)` — returns `Either<A, B>`.

**Why:** Without a terminal, Effect's `Match` silently produces a return type that includes `MatchNotCovered`, and at runtime an unmatched value falls through to `undefined`. The whole point of reaching for `Match` instead of a `switch` is to get the compiler to prove you handled every case. If you don't close the chain, you've re-created the same problem `switch (x.type) { case ...: }` has without a `default: absurd(x)`.

## Before (flagged)

```ts
// No terminal — unmatched variants return `undefined` at runtime
const label = Match.value(event).pipe(
  Match.when({ type: "kill" }, () => "killed"),
  Match.when({ type: "vote" }, () => "voted"),
);
```

## After (preferred) — exhaustive

```ts
const label = Match.value(event).pipe(
  Match.when({ type: "kill" }, () => "killed"),
  Match.when({ type: "vote" }, () => "voted"),
  Match.when({ type: "join" }, () => "joined"),
  Match.exhaustive, // compile error if any variant is missed
);
```

## After (preferred) — explicit fallback

```ts
const label = Match.value(event).pipe(
  Match.when({ type: "kill" }, () => "killed"),
  Match.when({ type: "vote" }, () => "voted"),
  Match.orElse(() => "unknown"), // explicit catchall
);
```

## When to suppress

Open-ended dispatch where a default is genuinely desired and you want to opt out of exhaustiveness (e.g., an RPC router where new methods can be added without a compiler touch-up):

```ts
// eslint-disable-next-line safer-by-default/match-requires-exhaustive -- intentionally open for forward compat
const handler = Match.value(method).pipe(
  Match.when("hello", () => hello),
  Match.when("ping", () => ping),
);
```

## Related rules

- None directly, but see the skill's "Switch over union" row in the decision table.
