# `safer-by-default/no-env-at-module-load`

**What it flags:** `process.env.X` or `process.env["X"]` reads at the program's top level — i.e., the value is computed as part of module load (imports), not lazily inside a function, a Layer, or a class.

**Why:** Module-load env reads break three things:

1. **Typed errors.** A missing var throws at import time, before any Effect bootstrap runs. Your `ConfigError` handling never gets a chance.
2. **Testability.** The read happens once, at `import`. Tests that do `process.env.X = "..."` in `beforeEach` have no effect because the import already captured the old value.
3. **Visibility.** Dependencies on environment are invisible from the outside — consumers can't look at the exported shape and see that this module requires `DATABASE_URL`.

`Effect.Config` fixes all three: the read is lazy (fires when the Layer runs), failures are typed in the error channel, and the config surface is visible in the Layer's type.

## Before (flagged)

```ts
// logger.ts — read at every import of this module
const logger = pino({
  level: process.env.LOG_LEVEL ?? "info",
  transport: process.env.NODE_ENV !== "production" ? ... : undefined,
});

export { logger };
```

```ts
// config.ts — similar pattern
const DATABASE_URL = process.env.DATABASE_URL!;
```

## After (preferred)

```ts
// logger.ts — a Layer, not a module-load side effect
import { Config, Context, Effect, Layer } from "effect";
import pino from "pino";

export class Logger extends Context.Tag("Logger")<Logger, pino.Logger>() {}

export const LoggerLive = Layer.effect(
  Logger,
  Effect.gen(function* () {
    const level = yield* Config.string("LOG_LEVEL").pipe(
      Config.withDefault("info"),
    );
    const isDev = yield* Config.succeed(process.env.NODE_ENV !== "production");
    return pino({
      level,
      transport: isDev ? { target: "pino-pretty" } : undefined,
    });
  }),
);
```

Consumers now have the dependency in their type: `Effect.Effect<A, E, Logger>`, and tests can `Layer.provide(Layer.succeed(Logger, fakeLogger))` without mutating `process.env`.

## When to suppress

Scripts and CLI entry points genuinely need to read env at start. If the whole script is a one-shot, suppress at the site:

```ts
// eslint-disable-next-line safer-by-default/no-env-at-module-load -- CLI script entrypoint, runs once
const DRY_RUN = process.env.DRY_RUN === "1";
main({ dryRun: DRY_RUN });
```

## Related rules

- `safer-by-default/no-hardcoded-secrets` — the same "environment is a boundary" principle, applied to literals instead of reads.
