# `safer-by-default/no-runsync-resource-in-class`

**What it flags:** `Effect.runSync(X)` where `X` constructs an Effect resource (`Ref.make`, `Deferred.make`, `Effect.makeSemaphore`, `Scope.make`, `Queue.unbounded`, `Hub.bounded`, etc.) and the call sits inside a class body — a field initializer, a constructor, or a method body.

**Why:** Running Effects synchronously inside a class leaks two guarantees the Layer system is designed to give you:

1. **Async-safety.** `Effect.runSync` throws if the inner Effect is ever async. Resource constructors are pure *today* but any refactor that adds acquisition logic (e.g., `Ref.make` wrapped in `Scope` tracking, `Deferred.make` coordinated through a service) turns the class constructor into a runtime bomb.
2. **Scope-tied finalizers.** Resources built with `Effect.runSync` aren't attached to any `Scope`. When the app shuts down, finalizers — log flushing, DB close, in-flight request drain — don't run. The equivalent resource built inside `Layer.effect` is automatically torn down when the Layer is released.

The correct shape is to construct the resource in a `Layer.effect` (or `Layer.scoped`) and inject it through the class's constructor.

## Before (flagged)

```ts
class AppHost {
  private inflightPermissions = Effect.runSync(
    Ref.make(HashMap.empty<string, Deferred.Deferred<string[], Error>>()),
  );

  constructor(private db: Db, private broadcaster: Broadcaster) {}
}
```

## After (preferred)

```ts
class AppHost {
  constructor(
    private db: Db,
    private broadcaster: Broadcaster,
    private inflightPermissions: Ref.Ref<
      HashMap.HashMap<string, Deferred.Deferred<string[], Error>>
    >,
  ) {}
}

export const AppHostLive = Layer.effect(
  AppHostTag,
  Effect.gen(function* () {
    const db = yield* DbTag;
    const broadcaster = yield* BroadcasterTag;
    const inflightPermissions = yield* Ref.make(HashMap.empty());
    return new AppHost(db, broadcaster, inflightPermissions);
  }),
);
```

## When to suppress

The entry-point where Effect meets the outside world (e.g., the module that wires the root `Layer` into an HTTP server) legitimately does one `Effect.runSync` or `Effect.runPromise`. If your class happens to be that entry point, suppress with a written reason:

```ts
class Bootstrap {
  // eslint-disable-next-line safer-by-default/no-runsync-resource-in-class -- entry-point bridge, top of the dependency tree
  private rootScope = Effect.runSync(Scope.make());
}
```

## Related rules

- `safer-by-default/bare-catch` — often co-occurs in classes that also do ad-hoc error handling.
- `safer-by-default/async-keyword` — same anti-pattern family (sync escape hatches in Effect code).
