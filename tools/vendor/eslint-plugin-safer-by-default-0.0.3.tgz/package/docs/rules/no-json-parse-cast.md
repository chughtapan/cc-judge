# `safer-by-default/no-json-parse-cast`

**What it flags:** `JSON.parse(x) as SomeType` — a TypeScript cast applied directly to the result of `JSON.parse`. The cast lies to the compiler: `JSON.parse` returns `any` at runtime, which the cast launders into `SomeType` without checking anything about the actual shape.

The rule permits two forms:

- `JSON.parse(x) as unknown` — forces the reader to decode before use. Explicitly unsafe and explicitly deferred.
- `JSON.parse(x) as const` — const-narrowing of a literal, no shape assumption.

**Why:** `JSON.parse` is the single most common trust boundary in a TypeScript codebase: HTTP request/response bodies, localStorage reads, webhook payloads, IPC messages, WebSocket frames, DB JSON columns. Every one of those is data you don't control and can't trust. A silent cast means malformed input flows downstream as if it were well-typed, and the bug surfaces deep in business logic with a message like `Cannot read properties of undefined`.

Decode with a schema at the boundary, once, and let the type system take it from there.

## Before (flagged)

```ts
const body = JSON.parse(request.body) as { userId: string; amount: number };
chargeUser(body.userId, body.amount);
```

## After — Effect Schema

```ts
import { Effect, Schema } from "effect";

const ChargeRequest = Schema.Struct({
  userId: Schema.String,
  amount: Schema.Number,
});

const body = yield* Schema.decodeUnknown(ChargeRequest)(JSON.parse(request.body));
chargeUser(body.userId, body.amount);
```

## After — Zod

```ts
import { z } from "zod";

const ChargeRequest = z.object({
  userId: z.string(),
  amount: z.number(),
});

const body = ChargeRequest.parse(JSON.parse(request.body));
chargeUser(body.userId, body.amount);
```

## After — deferred decode (explicit unsafe)

```ts
const raw = JSON.parse(request.body) as unknown;
// Passed into a downstream decoder later in the pipeline
processIncoming(raw);
```

## When to suppress

Only when `JSON.parse` is reading data your own process wrote in the same session, from a source you control end-to-end (e.g., a test fixture):

```ts
// eslint-disable-next-line safer-by-default/no-json-parse-cast -- test fixture written by the same suite
const snapshot = JSON.parse(fs.readFileSync("fixture.json", "utf8")) as Snapshot;
```

## Related rules

- `safer-by-default/record-cast` — same family: casting to `Record<string, unknown>` to escape type-checking.
- `safer-by-default/no-manual-enum-cast` — casting strings to string-union types.
