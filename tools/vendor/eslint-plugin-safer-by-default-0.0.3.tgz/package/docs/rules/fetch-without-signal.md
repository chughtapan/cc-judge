# `safer-by-default/fetch-without-signal`

**What it flags:** `Effect.tryPromise({ try: () => fetch(...) })` where the `try` arrow takes no parameter. The first parameter of `try` is an `AbortSignal` that Effect's fiber interrupt wires to; if you drop it, the HTTP request isn't aborted when the surrounding Effect is cancelled and the socket leaks.

**Why:** `Effect.tryPromise` is the correct primitive at I/O edges, but it only delivers on its interrupt-safety promise if you actually forward the signal. In practice:

- Shutdown signals (SIGTERM, graceful drain): pending webhooks keep running until the HTTP timeout.
- Upstream `Effect.timeout`: the outer Effect succeeds with a `TimeoutException`, but the inner fetch continues in the background, holds a connection, and may mutate state.
- Load-shedding cancellations under backpressure: accumulate leaked sockets, eventually starving the pool.

One parameter change closes all three.

## Before (flagged)

```ts
Effect.tryPromise({
  try: () => fetch(url, { method: "POST", body }),
  catch: (err) => new HttpError({ cause: err }),
});
```

## After (preferred)

```ts
Effect.tryPromise({
  try: (signal) => fetch(url, { method: "POST", body, signal }),
  catch: (err) => new HttpError({ cause: err }),
});
```

## When to suppress

Other async sources don't take an `AbortSignal` (most database drivers, some SDKs). The rule only flags the case where `fetch` is actually called inside the `try` body, so those shouldn't trigger it. If they do, it's a false positive:

```ts
// eslint-disable-next-line safer-by-default/fetch-without-signal -- driver has no abort surface
Effect.tryPromise({
  try: () => db.query("SELECT 1"),
  catch: (err) => new DbError({ cause: err }),
});
```

## Related rules

- `safer-by-default/effect-catch-untyped` — the companion rule on the `catch` side of the same `Effect.tryPromise`.
