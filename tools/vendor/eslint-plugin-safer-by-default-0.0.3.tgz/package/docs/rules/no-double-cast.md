# `safer-by-default/no-double-cast`

**What it flags:** `X as unknown as Y` (and `X as any as Y`) — a two-step cast that routes through `unknown` or `any` to silence any type-check failure the direct cast `X as Y` would have produced.

TypeScript lets you cast anything to `unknown` (safely) and lets you cast `unknown` to anything (unsafely). Chain them and you've bypassed the type system entirely: the compiler accepts `X as unknown as Y` even when `X` and `Y` have nothing structurally in common.

## Why

Every `as unknown as` is one of two things:

1. **A deliberate escape hatch** — phantom-type witnesses (`null as unknown as Static<T>`), reflection into private state (`(svc as unknown as { _x: number })._x`), or bridging a generic function to a non-generic mock (`vi.fn() as unknown as Generic<T>`). These are legitimate, but they should be *marked* as escape hatches so reviewers can see the load-bearing assumption. Leave a disable directive with a one-line reason.

2. **A bug under the rug.** A single `X as Y` would have triggered a `Conversion of type 'X' to type 'Y' may be a mistake because neither type sufficiently overlaps with the other` error. `as unknown as` silences that error without fixing it. The mismatch surfaces later, usually at runtime.

Distinguishing the two takes deliberate judgment. Force yourself to make that judgment at the call site, not a week later when the production logs are screaming.

## Before (flagged)

```ts
// Bug under the rug: ErrorType is a tagged union but this cast pretends
// it's always the RpcServerError variant, silently mismatching on defects.
const err = result.left as unknown as { code: number; message: string };
expect(err.code).toBe(401);
```

```ts
// Lazy "I know better than TS": if `createDb` actually returns something
// structurally incompatible with Kysely<Database>, this breaks at runtime
// instead of at compile time where it should.
return makeEffectKysely<Database>(config) as unknown as Kysely<Database>;
```

## After — proper narrow

```ts
// Effect.catchTag narrows the tagged union declaratively; no cast needed.
yield* rpc.pipe(
  Effect.catchTag("RpcServerError", (err) => {
    expect(err.code).toBe(401);
    return Effect.succeed(err);
  }),
);
```

```ts
// `EffectKysely<DB>` is a type alias for `Kysely<DB>` — the cast was a no-op
// masquerading as a conversion. Just remove it.
return makeEffectKysely<Database>(config);
```

## After — explicit escape hatch

```ts
// Phantom type witness: `null` at runtime, carries `Static<P>` at type level.
// The cast IS the point; the disable says so.
return {
  // eslint-disable-next-line safer-by-default/no-double-cast -- phantom-type witness for compile-time inference
  Params: null as unknown as Static<P>,
};
```

```ts
// Test reaches into the parent class's private Ref via `this`.
// eslint-disable-next-line safer-by-default/no-double-cast -- test harness reaches parent's private state
private get internals(): ParentInternals {
  return this as unknown as ParentInternals;
}
```

## When to suppress

Reserve the disable directive for cases where the runtime shape is guaranteed by something outside the type system:

- Phantom types (runtime value is `null`/`undefined`, used only for type-level inference).
- Reflection into documented private state for tests.
- Bridging generic function types to a non-generic mock (`vi.fn()`, mocks with erased signatures).
- `this` widening inside a subclass to read a parent's private field.

Always include a one-line reason in the directive. A bare disable is worse than no rule.

## Related rules

- `safer-by-default/no-json-parse-cast` — the specific case of `JSON.parse(x) as T` at a trust boundary.
- `safer-by-default/record-cast` — escaping the type system by casting to `Record<string, unknown>`.
- `safer-by-default/no-manual-enum-cast` — casting strings to string-union types.
