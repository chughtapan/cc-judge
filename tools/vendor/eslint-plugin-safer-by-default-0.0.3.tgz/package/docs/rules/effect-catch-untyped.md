# `safer-by-default/effect-catch-untyped`

**What it flags:** `Effect.try` or `Effect.tryPromise` calls whose `catch` handler either returns the caught value unchanged (identity) or wraps it in a bare `new Error(...)`. Both leave the Effect error channel as `unknown` or the generic `Error` class, defeating the point of using Effect.

**Why:** The error channel is the contract between the producer and every consumer. If it's `unknown`, `Effect.catchAll` is the only tool available — `catchTag` and exhaustive pattern-matching stop working. If it's a bare `Error`, the consumer can't tell a webhook timeout apart from a parse failure, and policy decisions (retry? log? reject? circuit-break?) collapse into a single opaque branch.

Map every external failure to a `Data.TaggedError` variant at the edge. Your callers get exhaustiveness back, and the fix-class behavior is explicit.

## Before (flagged)

```ts
// Identity — error channel becomes `unknown`
Effect.tryPromise({
  try: () => fetch(url).then(r => r.json()),
  catch: (err) => err,
});

// Generic Error wrap — error channel becomes bare `Error`
Effect.tryPromise({
  try: () => fetch(url).then(r => r.json()),
  catch: (err) => new Error(String(err)),
});

// Ternary with Error fallback — still flagged
Effect.tryPromise({
  try: () => fetch(url).then(r => r.json()),
  catch: (err) => err instanceof Error ? err : new Error(String(err)),
});
```

## After (preferred)

```ts
import { Data, Effect } from "effect";

class FetchHttpError extends Data.TaggedError("FetchHttpError")<{
  readonly url: string;
  readonly status: number;
}> {}

class FetchNetworkError extends Data.TaggedError("FetchNetworkError")<{
  readonly url: string;
  readonly cause: unknown;
}> {}

Effect.tryPromise({
  try: (signal) => fetch(url, { signal }),
  catch: (cause) => new FetchNetworkError({ url, cause }),
});
```

Now downstream can `.catchTag("FetchNetworkError", retry).catchTag("FetchHttpError", circuitBreak)` with compile-time exhaustiveness.

## When to suppress

If the error channel is genuinely discarded immediately (`Effect.catchAll(() => Effect.succeed(fallback))` directly after the call, nothing else reachable), suppress with a written reason:

```ts
// eslint-disable-next-line safer-by-default/effect-catch-untyped -- fire-and-forget logger, no downstream consumer
Effect.tryPromise({ try: () => logRemote(x), catch: (err) => err });
```
